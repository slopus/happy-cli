---
name: ios-ui-automation
description: Automate UI interactions in iOS simulator - tap elements, enter text, swipe, and verify UI state for testing
license: MIT
---

# Ios Ui Automation

TODO: Add your instructions here that Claude will follow when this skill is active.

## Purpose

Describe what this skill helps Claude accomplish.

## When to Use

- Trigger condition 1
- Trigger condition 2
- Trigger condition 3

## Capabilities

- Capability 1
- Capability 2
- Capability 3

## Usage Examples

### Example 1: Basic Usage

```bash
# Command or usage pattern
```

### Example 2: Advanced Usage

```bash
# More complex usage
```

## Guidelines

- Guideline 1: Best practice
- Guideline 2: Important consideration
- Guideline 3: Common pitfall to avoid

## References

See files in the `references/` directory for detailed documentation.
